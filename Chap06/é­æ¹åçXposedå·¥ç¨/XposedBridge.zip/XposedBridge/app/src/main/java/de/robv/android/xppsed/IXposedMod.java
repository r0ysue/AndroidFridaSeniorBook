package de.robv.android.xppsed;

/** Marker interface for Xposed modules. Cannot be implemented directly. */
/* package */ interface IXposedMod {}
