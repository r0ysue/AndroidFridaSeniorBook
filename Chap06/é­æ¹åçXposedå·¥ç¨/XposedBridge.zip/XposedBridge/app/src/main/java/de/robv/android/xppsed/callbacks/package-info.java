/**
 * Contains the base classes for callbacks.
 *
 * <p>For historical reasons, {@link de.robv.android.xppsed.XC_MethodHook} and
 * {@link de.robv.android.xppsed.XC_MethodReplacement} are directly in the
 * {@code de.robv.android.xppsed} package.
 */
package de.robv.android.xppsed.callbacks;

