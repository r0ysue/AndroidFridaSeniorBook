/**
 * Contains {@link android.app.AndroidAppHelper} with various methods for information about the current app.
 */
package android.app;
