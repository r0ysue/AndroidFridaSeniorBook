/**
 * Contains file access services provided by the Xposed framework.
 */
package de.robv.android.xppsed.services;
