var BUILD_TIMESTAMP = "<?cs var:page.now ?>";
