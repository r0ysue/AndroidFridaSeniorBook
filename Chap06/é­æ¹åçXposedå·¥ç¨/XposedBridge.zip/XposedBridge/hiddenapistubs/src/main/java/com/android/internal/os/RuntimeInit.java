package com.android.internal.os;

public class RuntimeInit {
	public static final void main(String[] argv) {
		throw new UnsupportedOperationException("STUB");
	}
}
