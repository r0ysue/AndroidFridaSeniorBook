package android.app;

import android.content.pm.ApplicationInfo;

public final class LoadedApk {
	public ApplicationInfo getApplicationInfo() {
		throw new UnsupportedOperationException("STUB");
	}

	public ClassLoader getClassLoader() {
		throw new UnsupportedOperationException("STUB");
	}

	public String getPackageName() {
		throw new UnsupportedOperationException("STUB");
	}

	public String getResDir() {
		throw new UnsupportedOperationException("STUB");
	}
}
