package com.android.internal.os;

public class ZygoteInit {
	public static void main(String[] argv) {
		throw new UnsupportedOperationException("STUB");
	}
}
