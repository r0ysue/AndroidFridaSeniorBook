package de.robv.android.xppsed.installer.util;

public interface RunnableWithParam<T> {
    public void run(T param);
}
