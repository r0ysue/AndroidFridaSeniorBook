libart_fake
====

A fake libart made to satisfy some misbehaving apps that will attempt to link
against libart.so.
