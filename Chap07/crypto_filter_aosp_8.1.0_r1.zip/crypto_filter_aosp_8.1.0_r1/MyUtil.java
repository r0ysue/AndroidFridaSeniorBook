package javax.crypto;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyUtil {
    private static SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    public static HashSet<String> WhiteListSet = new HashSet<>(Arrays.asList("com.android.providers.telephony"
            ,"com.android.providers.calendar"
            ,"com.android.providers.media"
            ,"com.android.wallpapercropper"
            ,"com.android.documentsui"
            ,"com.android.galaxy4"
            ,"com.android.externalstorage"
            ,"com.android.htmlviewer"
            ,"com.android.quicksearchbox"
            ,"com.android.mms.service"
            ,"com.android.providers.downloads"
            ,"com.android.messaging"
            ,"com.android.browser"
            ,"com.android.soundrecorder"
            ,"com.android.defcontainer"
            ,"com.android.providers.downloads.ui"
            ,"com.android.pacprocessor"
            ,"com.qualcomm.cabl"
            ,"com.android.certinstaller"
            ,"com.android.carrierconfig"
            ,"android"
            ,"com.android.contacts"
            ,"com.android.camera2"
            ,"com.android.nfc"
            ,"com.android.launcher3"
            ,"com.android.backupconfirm"
            ,"com.android.provision"
            ,"org.codeaurora.ims"
            ,"com.android.statementservice"
            ,"com.android.wallpaper.holospiral"
            ,"com.android.calendar"
            ,"com.android.phasebeam"
            ,"com.qualcomm.qcrilmsgtunnel"
            ,"com.android.providers.settings"
            ,"com.android.sharedstoragebackup"
            ,"com.android.printspooler"
            ,"com.android.dreams.basic"
            ,"com.android.webview"
            ,"com.android.inputdevices"
            ,"com.android.musicfx"
            ,"com.android.onetimeinitializer"
            ,"com.android.server.telecom"
            ,"com.android.keychain"
            ,"com.android.dialer"
            ,"com.android.gallery3d"
            ,"com.android.calllogbackup"
            ,"com.android.packageinstaller"
            ,"com.svox.pico"
            ,"com.android.proxyhandler"
            ,"com.android.inputmethod.latin"
            ,"com.android.managedprovisioning"
            ,"com.android.dreams.phototable"
            ,"com.android.noisefield"
            ,"com.android.smspush"
            ,"com.android.wallpaper.livepicker"
            ,"com.android.apps.tag"
            ,"com.android.settings"
            ,"com.android.calculator2"
            ,"com.android.wallpaper"
            ,"com.android.vpndialogs"
            ,"com.android.email"
            ,"com.android.music"
            ,"com.android.phone"
            ,"com.android.shell"
            ,"com.android.providers.userdictionary"
            ,"com.android.location.fused"
            ,"com.android.deskclock"
            ,"com.android.systemui"
            ,"com.android.bluetoothmidiservice"
            ,"com.google.android.launcher.layouts.angler"
            ,"com.android.bluetooth"
            ,"com.qualcomm.timeservice"
            ,"com.android.providers.contacts"
            ,"com.android.captiveportallogin"
            ,"com.guoshi.httpcanary"
    ));

    public static String readPackageNameFromFile() {
        String pn = getTargetPkgName("/data/local/tmp/monitor_package");
        ContextHolder.logInfo("monitor_package: " + pn);
        if (pn.isEmpty()){
            ContextHolder.logWarning("error:/data/local/tmp/monitor_package is not found the target app package name");
        }
        return pn;
    }

    public static boolean isWhiteList(String packageName) {
        boolean bret = false;
        if (WhiteListSet.contains(packageName)) {
            bret = true;
        }

        return bret;
    }


    // ***** fishso 支持多行，即多个app
    public static String getTargetPkgName(String filepath) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(filepath));
            String line;
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                //System.out.println(line);
                sb.append(line.trim()).append(",");
            }

            br.close();
            return sb.toString();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "";
    }


    public static synchronized void addLog(String content, String packageName) {
        // json打印时自动换行,前面留几个空格
        MyUtil.appendFile("/data/data/" + packageName + "/crypto_log", content.replace(",", ",\n    ") + "\r\n");
    }

    public static void appendFile(String filepath, String content) {
        ContextHolder.logInfo("********filepath:" + filepath + ",content:********\n" + content);
        
        Date date = new Date(System.currentTimeMillis());
        String dateString = dateFormat.format(date);
        //FileLock lock = null;
        try {
            File file = new File(filepath);
            if (!file.exists()) {
                file.createNewFile();
            }

            FileWriter fileWriter = new FileWriter(filepath, true);
            fileWriter.write(dateString + " " + content);
            fileWriter.close();

            //lock.release();
        } catch (IOException e) {
            e.printStackTrace();
            ContextHolder.logWarning("appendFile excepiton:" + e.getMessage());
        }
    }


    public static int LIMIT_SIZE = 5 * 1024 * 1024;

    public static boolean check_oom(byte[] bs) {
        return false;
//        //10mb
//        if (bs.length > LIMIT_SIZE) {
//            return true;
//        }
//        return false;
    }

    public static boolean check_oom(ByteBuffer bs) {
        return false;
        //10mb
//        if (bs.position() > LIMIT_SIZE) {
//            return true;
//        }
//        return false;
    }

    public static boolean check_oom(ArrayList<Byte> bs) {
        return false;
//        //10mb
//        if (bs.size() > LIMIT_SIZE) {
//            return true;
//        }
//        return false;
    }

    /**
     * Lower case Hex Digits.
     */
    private static final String HEX_DIGITS = "0123456789abcdef";

    /**
     * Byte mask.
     */
    private static final int BYTE_MSK = 0xFF;

    /**
     * Hex digit mask.
     */
    private static final int HEX_DIGIT_MASK = 0xF;

    /**
     * Number of bits per Hex digit (4).
     */
    private static final int HEX_DIGIT_BITS = 4;


    public static String toHexString(final byte[] byteArray) {
        StringBuilder sb = new StringBuilder(byteArray.length * 2);
        for (int i = 0; i < byteArray.length; i++) {
            int b = byteArray[i] & BYTE_MSK;
            sb.append(HEX_DIGITS.charAt(b >>> HEX_DIGIT_BITS)).append(
                    HEX_DIGITS.charAt(b & HEX_DIGIT_MASK));
        }
        return sb.toString();
    }

    public static String byteArrayToString(byte[] input) {
        if(input==null)
            return "";
        String out = new String(input);
        int tmp = 0;
        for (int i = 0; i < out.length(); i++) {
            int c = out.charAt(i);

            if (c >= 32 && c < 127) {
                tmp++;
            }
        }

        if (tmp > (out.length() * 0.60)) {
            StringBuilder sb = new StringBuilder();
            for (byte b : input) {
                if (b >= 32 && b < 127)
                    sb.append(String.format("%c", b));
                else
                    sb.append('.');
            }
            out = sb.toString();

        } else {
            out = AndroidBase64.encodeToString(input, AndroidBase64.NO_WRAP);
        }

        return out;
    }


}
